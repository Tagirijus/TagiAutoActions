<li <?= $this->app->checkMenuSelection('TagiAutoActionsController', 'showConfig') ?>>
    <a href="/tagiautoactions/config"><?= t('TagiAutoActions configuration') ?></a>
</li>
