<?php

return array(
    'Settings' => 'Einstellungen',
    'TagiAutoActions configuration' => 'TagiAutoActions Einstellungen',
    'Remove the tasks due date when the task is moved to a certain column' => 'Lösche das Fälligkeitsdatum eines Tasks, wenn dieser in eine bestimmte Spalte verschoben wird',
    'Priority colors' => 'Prioritäts-Farben',
    'Here you can set the color names for each priority level from 0 to 3. Possible colors are: yellow, blue, green, purple, red, orange, grey, brown, deep_orange, dark_grey, pink, teal, cyan, lime, light_green, amber.' => 'Hier kann man die Farben für jede der Prioritätsstufen von 0 bis 3 setzen. Mögliche Farbwerte sind: yellow, blue, green, purple, red, orange, grey, brown, deep_orange, dark_grey, pink, teal, cyan, lime, light_green, amber.',
    'Priority' => 'Priorität',
    'Set color based on priority of the task. Yet with 0-3 priority levels assigned in the config.' => 'Eine Farbe basierend auf der Priorität der Aufgabe zuweisen. Allerdings mit allen 0-3 Prioritäts-Leveln, die man näher in der Config befärben kann.',
    'Move task to end of column, when it is moved into a specific column.' => 'Setze Aufgabe ans Ende der Spalte, sobald die Aufgabe in eine gewisse Spalte geschoben wird.',
);
